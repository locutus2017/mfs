================
wxPython Phoenix
================


Introduction
============

Phoenix is a new implementation of wxPython focused on improving speed,
maintainability and extensibility. Just like wxPython it wraps the wxWidgets
C++ toolkit and provides access to the UI portions of the wx API, enabling
Python applications to have a GUI on Windows, Macs or Unix systems with a
native look and feel and requiring very little (if any) platform specific code.



More to be written...


