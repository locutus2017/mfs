/* Phony config file used only to shut up certain versions og GoI's
   regress.c which does unconditional #include "config.h". */
